<?php get_header(); ?>
<!-- content -->
<main class="content">
    <div class="page-not-found">
        <h1>404</h1>
        <h2>Page Not Found.</h2>
        <p>The resource requested could not found on the server.</p>
    </div>

</main>
<?php get_footer(); ?>